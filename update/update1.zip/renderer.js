// --- ZEGAR I DATA ---
function updateClock() {
  const now = new Date();
  const time = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
  const date = now.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  document.getElementById('clock').textContent = `${time} | ${date}`;
}
setInterval(updateClock, 1000);
updateClock();

// --- START I SPRAWDZANIE UPDATE ---
async function initLauncher() {
  const loadingScreen = document.getElementById('loading-screen');
  const loadingText = document.getElementById('loading-text');
  const appLayout = document.getElementById('app-layout');

  loadingText.textContent = "CHECKING FOR UPDATES...";
  loadingScreen.classList.remove('hidden');

  try {
    // Pytamy main.js czy na GitHubie jest nowy update1.zip
    const updateRes = await window.foxClient.checkUpdate();
    
    if (updateRes.hasUpdate) {
      loadingText.textContent = "DOWNLOADING UPDATE...";
      await new Promise(r => setTimeout(r, 1500)); 
    }
  } catch (e) {
    console.error("Błąd update:", e);
  } finally {
    // Koniec ładowania - pokazujemy menu
    loadingScreen.classList.add('hidden');
    appLayout.classList.remove('hidden');
  }
}

initLauncher();

// --- KONTROLA OKNA ---
document.querySelectorAll('.win-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const action = btn.dataset.win;
    if (action === 'min') window.foxClient.window.minimize();
    if (action === 'max') window.foxClient.window.maximize();
    if (action === 'close') window.foxClient.window.close();
  });
});

// --- NAWIGACJA (ŚRODEK) ---
document.getElementById('btn-instances').addEventListener('click', () => {
  document.getElementById('view-play').classList.remove('active');
  document.getElementById('view-instances').classList.add('active');
});

document.getElementById('btn-mods').addEventListener('click', () => {
  document.getElementById('view-play').classList.remove('active');
  document.getElementById('view-mods').classList.add('active');
});

// --- URUCHAMIANIE GRY ---
document.getElementById('play-btn').addEventListener('click', async () => {
  const btn = document.getElementById('play-btn');
  const originalText = btn.innerHTML;
  
  btn.innerHTML = 'LAUNCHING...';
  btn.disabled = true;

  setTimeout(() => {
    alert("Funkcja odpalania gry jest wyłączona podczas testów UI.");
    btn.innerHTML = originalText;
    btn.disabled = false;
  }, 1000);
});

// --- MODY ---
document.getElementById('mods-search-btn').addEventListener('click', async () => {
  const query = document.getElementById('mods-search').value.trim();
  const grid = document.getElementById('mods-grid');
  grid.innerHTML = '<div style="color:#888; padding:10px; font-size:14px;">Loading...</div>';
  
  try {
    const res = await window.foxClient.modrinth.search(query);
    if (!res.ok) throw new Error(res.error);
    
    grid.innerHTML = res.data.hits.map(m => `
      <div class="list-item">
        <img src="${m.icon_url || ''}">
        <div class="list-item-info">
          <h4>${escapeHtml(m.title)}</h4>
          <p>${escapeHtml(m.description || '').substring(0, 60)}...</p>
        </div>
        <button class="modern-btn">INSTALL</button>
      </div>
    `).join('');
  } catch (err) {
    grid.innerHTML = `<div style="color:#ff5555; padding:10px; font-size:14px;">Error: ${err.message}</div>`;
  }
});

function escapeHtml(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}